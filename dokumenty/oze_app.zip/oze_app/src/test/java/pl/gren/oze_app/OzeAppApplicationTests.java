package pl.gren.oze_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OzeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
